#[no_mangle]
pub extern "C" fn rust_function1() {
    println!("Hello from lib 1!");
}
