#[no_mangle]
pub extern "C" fn ret_12() -> u32 {
    12
}
