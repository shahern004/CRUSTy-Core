#include <stdio.h>

void c_function(char const *name) {
   printf("Hello %s, I am an external C function\n", name);
}
